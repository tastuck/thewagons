coachella 2017 stages
--coachella stage
--outdoor theatre
--mojave
--gobi
--sahara
--sonora
--yuma

rock in rio 2017
--palco mundo
--palco sunset
--electronica

tomorrowland 2024
--life
--core
--planaxis
--freedom stage
--crystal garden
--melodia
--atmosphere
--house of fortune
--the library
--the rose garden
--elixir
--the rave cave
--rise
--cage
--portal to paradise

lollapolooza 2021
--bud light seltzer
--titos handmade vodka
--grove
--bmi
--perry's
--lakeshore
--tmobile

dreamville 2025
--rise
--shine

camp flog gnaw

desert daze